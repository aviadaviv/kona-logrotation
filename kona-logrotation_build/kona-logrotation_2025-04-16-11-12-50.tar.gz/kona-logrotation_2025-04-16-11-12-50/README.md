# kona-logrotation
grafana-agent for discovery applications